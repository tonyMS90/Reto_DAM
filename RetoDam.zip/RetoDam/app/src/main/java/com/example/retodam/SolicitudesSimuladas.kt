package com.example.retodam

object SolicitudesSimuladas {
    val listaSolicitudes = mutableListOf<Solicitud>()
}
