package com.example.retodam

object UsuarioSession {
    var usuarioActual: Usuario?= null
}